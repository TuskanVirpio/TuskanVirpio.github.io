Please don't log issues for general discussions or non code problems. Instead, join us on Slack for a chat.

https://eveseat.github.io/docs/about/contact/

For some help on where to find logs, put SeAT into DEBUG mode etc, please refer to the following link:

https://eveseat.github.io/docs/about/reporting_bugs/

Thanks for wanting to report an issue you've found in SeAT. Please delete
this text and fill in the template below. If you are unsure about something,
just do as best as you're able.

* **Problem**: _Whats wrong?_
* **Expected**: _What did you expect to happen?_
* **Logs / Screenshots / Proof**: _The more information you give the better!_
* **Version Info**: _PHP Version, SeAT Version, Operating System etc._
